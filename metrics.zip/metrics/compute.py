"""
metrics/compute.py
------------------
Compute all 10 candidate ERA metrics for a single level (2D numpy array).

Each metric function:
  - accepts a level: np.ndarray (int32, shape H×W)
  - accepts a domain: str  ("mario" | "dungeon")
  - returns a float in a documented range

Call compute_all(level, domain) to get a dict of all metrics at once.

Metrics implemented
-------------------
1.  leniency          — how easy the level is for a player
2.  linearity         — how straight the critical path is
3.  density           — proportion of solid tiles
4.  tile_entropy      — Shannon entropy over tile-transition bigrams
5.  compressibility   — zlib compression ratio (proxy for Kolmogorov complexity)
6.  path_diversity    — number of distinct A*-equivalent shortest paths (sampled)
7.  solvability       — binary: does an A* agent find a path? (0.0 or 1.0)
8.  symmetry          — bilateral (left–right) symmetry score
9.  open_area_ratio   — connected open space vs. enclosed pockets
10. pattern_frequency — normalised frequency of the single most common tile n-gram
"""

import zlib
import heapq
import math
from collections import Counter, deque
from itertools import product
from typing import Dict, Set, Tuple

import numpy as np

from levels.loader import MARIO_SOLID, DUNGEON_SOLID

# ── Helpers ───────────────────────────────────────────────────────────────────

def _solid_set(domain: str) -> Set[int]:
    return MARIO_SOLID if domain == "mario" else DUNGEON_SOLID


def _passable(level: np.ndarray, r: int, c: int, solid: Set[int]) -> bool:
    H, W = level.shape
    return 0 <= r < H and 0 <= c < W and level[r, c] not in solid


def _start_goal_mario(level: np.ndarray) -> Tuple[Tuple, Tuple]:
    """For Mario: start = bottom-left open cell, goal = bottom-right open cell."""
    H, W = level.shape
    solid = MARIO_SOLID
    # Walk up from the bottom-left until we find an open cell
    for r in range(H - 1, -1, -1):
        if level[r, 0] not in solid:
            start = (r, 0)
            break
    else:
        start = (H - 2, 0)
    for r in range(H - 1, -1, -1):
        if level[r, W - 1] not in solid:
            goal = (r, W - 1)
            break
    else:
        goal = (H - 2, W - 1)
    return start, goal


def _start_goal_dungeon(level: np.ndarray) -> Tuple[Tuple, Tuple]:
    """For dungeon: start = first open cell, goal = last open cell."""
    H, W = level.shape
    solid = DUNGEON_SOLID
    open_cells = [(r, c) for r in range(H) for c in range(W)
                  if level[r, c] not in solid]
    if len(open_cells) < 2:
        return (0, 0), (H - 1, W - 1)
    return open_cells[0], open_cells[-1]


def _astar(level: np.ndarray, start: Tuple, goal: Tuple,
           solid: Set[int]) -> list:
    """
    A* search. Returns path as list of (r, c) tuples, or [] if unsolvable.
    Movement: 4-directional (up/down/left/right).
    """
    H, W = level.shape
    def heuristic(a, b):
        return abs(a[0] - b[0]) + abs(a[1] - b[1])

    open_heap = [(heuristic(start, goal), 0, start, [start])]
    visited = set()

    while open_heap:
        f, g, current, path = heapq.heappop(open_heap)
        if current in visited:
            continue
        visited.add(current)
        if current == goal:
            return path
        r, c = current
        for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            nr, nc = r + dr, c + dc
            if _passable(level, nr, nc, solid) and (nr, nc) not in visited:
                new_path = path + [(nr, nc)]
                new_g = g + 1
                heapq.heappush(open_heap,
                               (new_g + heuristic((nr, nc), goal),
                                new_g, (nr, nc), new_path))
    return []


# ── Individual metrics ────────────────────────────────────────────────────────

def leniency(level: np.ndarray, domain: str) -> float:
    """
    Mario: fraction of bottom-row cells that are gaps (non-solid).
    Higher = easier (more forgiving terrain, fewer pits).
    Dungeon: 1 - (trap tile density), where trap = tile id 3.
    Range: [0, 1].
    """
    H, W = level.shape
    if domain == "mario":
        bottom = level[-1, :]
        gaps = np.sum(np.isin(bottom, list(MARIO_SOLID), invert=True))
        return float(gaps) / W
    else:
        traps = np.sum(level == 3)
        return 1.0 - (traps / level.size)


def linearity(level: np.ndarray, domain: str) -> float:
    """
    Straightness of the A* critical path relative to the Manhattan straight line.
    1.0 = perfectly straight; 0.0 = maximally winding.
    Returns NaN if the level is unsolvable.
    """
    solid = _solid_set(domain)
    start, goal = (_start_goal_mario(level) if domain == "mario"
                   else _start_goal_dungeon(level))
    path = _astar(level, start, goal, solid)
    if not path:
        return float("nan")
    manhattan = abs(goal[0] - start[0]) + abs(goal[1] - start[1])
    if manhattan == 0:
        return 1.0
    return manhattan / len(path)   # ≤ 1; equals 1 only for a perfectly straight path


def density(level: np.ndarray, domain: str) -> float:
    """
    Proportion of tiles that are solid.
    Range: [0, 1].
    """
    solid = _solid_set(domain)
    solid_count = sum(np.sum(level == s) for s in solid)
    return float(solid_count) / level.size


def tile_entropy(level: np.ndarray, domain: str) -> float:
    """
    Shannon entropy over horizontal tile-transition bigrams (pairs of adjacent tiles).
    Higher entropy = more varied transitions = more structural complexity.
    Range: [0, log2(n_bigram_types)].
    """
    bigrams = []
    H, W = level.shape
    for r in range(H):
        for c in range(W - 1):
            bigrams.append((int(level[r, c]), int(level[r, c + 1])))
    counts = Counter(bigrams)
    total = sum(counts.values())
    if total == 0:
        return 0.0
    entropy = 0.0
    for count in counts.values():
        p = count / total
        entropy -= p * math.log2(p)
    return entropy


def compressibility(level: np.ndarray, domain: str) -> float:
    """
    zlib compression ratio of the raw tile bytes.
    Lower ratio = more repetitive / structured (higher compressibility).
    Range: (0, 1]; 1.0 means no compression was achieved.
    """
    raw = level.astype(np.uint8).tobytes()
    compressed = zlib.compress(raw, level=9)
    return len(compressed) / len(raw)


def path_diversity(level: np.ndarray, domain: str,
                   n_samples: int = 50, rng_seed: int = 0) -> float:
    """
    Estimated number of distinct shortest paths, normalised by n_samples.
    Uses random restarts of A* with tie-breaking noise to sample diverse paths.
    Range: [0, 1] (fraction of samples that produced a unique path).
    """
    solid = _solid_set(domain)
    start, goal = (_start_goal_mario(level) if domain == "mario"
                   else _start_goal_dungeon(level))
    rng = np.random.default_rng(rng_seed)
    seen_paths: Set[Tuple] = set()

    for _ in range(n_samples):
        # Add tiny random perturbation to heuristic to break ties differently
        noise = rng.uniform(0, 0.01)

        def heuristic_noisy(a, b, _noise=noise):
            return abs(a[0] - b[0]) + abs(a[1] - b[1]) + _noise

        H, W = level.shape
        open_heap = [(heuristic_noisy(start, goal), 0, start, [start])]
        visited: Set[Tuple] = set()
        found = []

        while open_heap:
            f, g, current, path = heapq.heappop(open_heap)
            if current in visited:
                continue
            visited.add(current)
            if current == goal:
                found = path
                break
            r, c = current
            neighbors = [(-1, 0), (1, 0), (0, -1), (0, 1)]
            rng.shuffle(neighbors)
            for dr, dc in neighbors:
                nr, nc = r + dr, c + dc
                if _passable(level, nr, nc, solid) and (nr, nc) not in visited:
                    new_g = g + 1
                    heapq.heappush(open_heap,
                                   (new_g + heuristic_noisy((nr, nc), goal),
                                    new_g, (nr, nc), path + [(nr, nc)]))

        if found:
            seen_paths.add(tuple(found))

    return len(seen_paths) / n_samples


def solvability(level: np.ndarray, domain: str) -> float:
    """
    1.0 if an A* agent finds a path from start to goal, else 0.0.
    """
    solid = _solid_set(domain)
    start, goal = (_start_goal_mario(level) if domain == "mario"
                   else _start_goal_dungeon(level))
    path = _astar(level, start, goal, solid)
    return 1.0 if path else 0.0


def symmetry(level: np.ndarray, domain: str) -> float:
    """
    Bilateral (left–right) symmetry score.
    1.0 = perfectly symmetric; 0.0 = maximally asymmetric.
    """
    flipped = np.fliplr(level)
    matches = np.sum(level == flipped)
    return float(matches) / level.size


def open_area_ratio(level: np.ndarray, domain: str) -> float:
    """
    Fraction of open (non-solid) tiles that belong to the largest connected
    open region. High value = one big open space; low value = many small pockets.
    Range: [0, 1].
    """
    solid = _solid_set(domain)
    H, W = level.shape
    open_mask = np.isin(level, list(solid), invert=True)
    total_open = int(np.sum(open_mask))
    if total_open == 0:
        return 0.0

    visited = np.zeros((H, W), dtype=bool)
    largest = 0

    for sr in range(H):
        for sc in range(W):
            if open_mask[sr, sc] and not visited[sr, sc]:
                # BFS flood-fill
                size = 0
                queue = deque([(sr, sc)])
                visited[sr, sc] = True
                while queue:
                    r, c = queue.popleft()
                    size += 1
                    for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                        nr, nc = r + dr, c + dc
                        if (0 <= nr < H and 0 <= nc < W
                                and open_mask[nr, nc] and not visited[nr, nc]):
                            visited[nr, nc] = True
                            queue.append((nr, nc))
                largest = max(largest, size)

    return largest / total_open


def pattern_frequency(level: np.ndarray, domain: str, n: int = 2) -> float:
    """
    Normalised frequency of the single most common horizontal tile n-gram.
    Higher = more repetitive patterning.
    Range: [0, 1].
    """
    H, W = level.shape
    if W < n:
        return 0.0
    ngrams = []
    for r in range(H):
        for c in range(W - n + 1):
            ngrams.append(tuple(int(level[r, c + i]) for i in range(n)))
    if not ngrams:
        return 0.0
    counts = Counter(ngrams)
    most_common_count = counts.most_common(1)[0][1]
    return most_common_count / len(ngrams)


# ── Main entry point ──────────────────────────────────────────────────────────

METRIC_FUNCTIONS = {
    "leniency":         leniency,
    "linearity":        linearity,
    "density":          density,
    "tile_entropy":     tile_entropy,
    "compressibility":  compressibility,
    "path_diversity":   path_diversity,
    "solvability":      solvability,
    "symmetry":         symmetry,
    "open_area_ratio":  open_area_ratio,
    "pattern_frequency": pattern_frequency,
}


def compute_all(level: np.ndarray, domain: str) -> Dict[str, float]:
    """
    Compute all 10 metrics for a single level.

    Parameters
    ----------
    level  : np.ndarray, shape (H, W), dtype int32
    domain : "mario" | "dungeon"

    Returns
    -------
    dict mapping metric name → float
    """
    results = {}
    for name, fn in METRIC_FUNCTIONS.items():
        try:
            results[name] = fn(level, domain)
        except Exception as e:
            results[name] = float("nan")
            print(f"[warn] {name} failed: {e}")
    return results
