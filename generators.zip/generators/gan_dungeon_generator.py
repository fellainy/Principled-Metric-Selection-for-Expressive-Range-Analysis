"""
generators/gan_dungeon_generator.py
------------------------------------
DCGAN-based Lode Runner level generator trained on VGLC dungeon levels.

Follows the same architecture as GANMarioGenerator but adapted for
the Lode Runner domain (22×32 tiles, 5-tile vocabulary).

Usage:
    from generators.gan_dungeon_generator import GANDungeonGenerator
    gen = GANDungeonGenerator(training_levels)
    gen.train(epochs=2000)
    levels = gen.generate_batch(n=2000)
"""

import numpy as np
from typing import List, Optional

try:
    import torch
    import torch.nn as nn
    import torch.optim as optim
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False
    print("[gan_dungeon] PyTorch not found. Using statistical fallback.")


if TORCH_AVAILABLE:

    class DungeonGenerator(nn.Module):
        def __init__(self, latent_dim: int, n_tiles: int,
                     height: int, width: int):
            super().__init__()
            self.latent_dim = latent_dim
            self.n_tiles    = n_tiles
            self.height     = height
            self.width      = width
            # Lode Runner: 22×32 → pad to 24×32 for clean 4x downsampling
            self.H_pad = 24
            self.W_pad = 32
            self.fc = nn.Linear(latent_dim,
                                256 * (self.H_pad // 4) * (self.W_pad // 4))
            self.net = nn.Sequential(
                nn.ConvTranspose2d(256, 128, 4, 2, 1),
                nn.BatchNorm2d(128),
                nn.ReLU(True),
                nn.ConvTranspose2d(128, 64, 4, 2, 1),
                nn.BatchNorm2d(64),
                nn.ReLU(True),
                nn.Conv2d(64, n_tiles, 3, 1, 1),
            )

        def forward(self, z):
            H4 = self.H_pad // 4
            W4 = self.W_pad // 4
            x = self.fc(z).view(-1, 256, H4, W4)
            out = self.net(x)                          # (B, n_tiles, H_pad, W_pad)
            return out[:, :, :self.height, :self.width]  # crop to real size

        def generate_levels(self, n: int,
                            rng: np.random.Generator) -> np.ndarray:
            self.eval()
            with torch.no_grad():
                z = torch.tensor(
                    rng.standard_normal((n, self.latent_dim)),
                    dtype=torch.float32
                )
                logits = self.forward(z)
                tiles  = logits.argmax(dim=1)
                return tiles.numpy().astype(np.int32)

    class DungeonDiscriminator(nn.Module):
        def __init__(self, n_tiles: int, height: int, width: int):
            super().__init__()
            H_pad = 24
            W_pad = 32
            self.pad = nn.ZeroPad2d((0, W_pad - width, 0, H_pad - height))
            self.net = nn.Sequential(
                nn.Conv2d(n_tiles, 64, 4, 2, 1),
                nn.LeakyReLU(0.2, True),
                nn.Conv2d(64, 128, 4, 2, 1),
                nn.BatchNorm2d(128),
                nn.LeakyReLU(0.2, True),
                nn.Flatten(),
                nn.Linear(128 * (H_pad // 4) * (W_pad // 4), 1),
                nn.Sigmoid(),
            )

        def forward(self, x):
            return self.net(self.pad(x))


class GANDungeonGenerator:
    """
    DCGAN generator for Lode Runner levels trained on VGLC data.
    Falls back to tile-frequency sampling if PyTorch is unavailable.
    """

    def __init__(self, training_levels: List[np.ndarray],
                 latent_dim: int = 32,
                 height: int = 22,
                 width: int = 32,
                 rng: Optional[np.random.Generator] = None):
        self.training_levels = training_levels
        self.latent_dim = latent_dim
        self.height     = height
        self.width      = width
        self.rng        = rng or np.random.default_rng(42)
        self.trained    = False

        # Build tile vocabulary
        all_tiles = set()
        for lvl in training_levels:
            all_tiles.update(np.unique(lvl).tolist())
        self.tile_vocab   = sorted(all_tiles)
        self.n_tiles      = len(self.tile_vocab)
        self.tile_to_idx  = {t: i for i, t in enumerate(self.tile_vocab)}
        self.idx_to_tile  = {i: t for t, i in self.tile_to_idx.items()}

        # Empirical tile frequencies for fallback
        counts = np.zeros(self.n_tiles)
        for lvl in training_levels:
            for t in self.tile_vocab:
                counts[self.tile_to_idx[t]] += np.sum(lvl == t)
        self.tile_probs = counts / counts.sum()

        if TORCH_AVAILABLE:
            self.G = DungeonGenerator(latent_dim, self.n_tiles, height, width)
            self.D = DungeonDiscriminator(self.n_tiles, height, width)

    def _levels_to_onehot(self, levels: List[np.ndarray]) -> "torch.Tensor":
        batch = np.zeros((len(levels), self.n_tiles,
                          self.height, self.width), dtype=np.float32)
        for i, lvl in enumerate(levels):
            h = min(lvl.shape[0], self.height)
            w = min(lvl.shape[1], self.width)
            for r in range(h):
                for c in range(w):
                    t = int(lvl[r, c])
                    if t in self.tile_to_idx:
                        batch[i, self.tile_to_idx[t], r, c] = 1.0
        return torch.tensor(batch)

    def train(self, epochs: int = 2000, batch_size: int = 16,
              lr: float = 0.0002, print_every: int = 500) -> None:
        if not TORCH_AVAILABLE:
            print("[gan_dungeon] PyTorch unavailable — skipping training.")
            return

        print(f"[gan_dungeon] Training on {len(self.training_levels)} "
              f"Lode Runner levels for {epochs} epochs…")

        real_data = self._levels_to_onehot(self.training_levels)
        n_real    = len(real_data)

        opt_G = optim.Adam(self.G.parameters(), lr=lr, betas=(0.5, 0.999))
        opt_D = optim.Adam(self.D.parameters(), lr=lr, betas=(0.5, 0.999))
        criterion = nn.BCELoss()

        for epoch in range(epochs):
            idx         = np.random.choice(n_real,
                                           size=min(batch_size, n_real),
                                           replace=True)
            real_batch  = real_data[idx]
            real_labels = torch.ones(len(idx), 1)
            fake_labels = torch.zeros(batch_size, 1)

            z         = torch.randn(batch_size, self.latent_dim)
            fake_soft = torch.softmax(self.G(z), dim=1)

            opt_D.zero_grad()
            loss_D = (criterion(self.D(real_batch), real_labels) +
                      criterion(self.D(fake_soft.detach()), fake_labels)) / 2
            loss_D.backward()
            opt_D.step()

            opt_G.zero_grad()
            z         = torch.randn(batch_size, self.latent_dim)
            fake_soft = torch.softmax(self.G(z), dim=1)
            loss_G    = criterion(self.D(fake_soft), real_labels[:batch_size])
            loss_G.backward()
            opt_G.step()

            if (epoch + 1) % print_every == 0:
                print(f"  Epoch {epoch+1}/{epochs}  "
                      f"loss_D={loss_D.item():.4f}  "
                      f"loss_G={loss_G.item():.4f}")

        self.trained = True
        print("[gan_dungeon] Training complete.")

    def generate_batch(self, n: int) -> List[np.ndarray]:
        if TORCH_AVAILABLE and self.trained:
            raw    = self.G.generate_levels(n, self.rng)
            levels = []
            for i in range(n):
                lvl = np.zeros((self.height, self.width), dtype=np.int32)
                for r in range(self.height):
                    for c in range(self.width):
                        lvl[r, c] = self.idx_to_tile.get(
                            int(raw[i, r, c]), 0)
                levels.append(lvl)
            return levels
        else:
            print("[gan_dungeon] Using tile-frequency fallback.")
            levels = []
            for _ in range(n):
                indices = self.rng.choice(self.n_tiles,
                                          size=(self.height, self.width),
                                          p=self.tile_probs)
                lvl = np.vectorize(self.idx_to_tile.get)(indices).astype(np.int32)
                levels.append(lvl)
            return levels

    def generate(self) -> np.ndarray:
        return self.generate_batch(1)[0]
