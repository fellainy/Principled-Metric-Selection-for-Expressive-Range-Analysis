"""
generators/wfc_dungeon_generator.py
------------------------------------
Real WFC generator trained on VGLC Lode Runner levels.

Learns horizontal and vertical adjacency constraints from the 150
Lode Runner training levels and generates new levels by constraint
propagation — identical architecture to WFCMarioGenerator but
tuned for the Lode Runner 22×32 tile grid.

Usage:
    from generators.wfc_dungeon_generator import WFCDungeonGenerator
    gen = WFCDungeonGenerator(training_levels)
    level = gen.generate(height=22, width=32)
"""

import numpy as np
from collections import defaultdict
from typing import List, Dict, Set, Tuple, Optional


class WFCDungeonGenerator:
    """
    WFC generator trained on VGLC Lode Runner levels.
    Generates new dungeon levels by tile-adjacency constraint propagation.
    """

    def __init__(self, training_levels: List[np.ndarray],
                 rng: Optional[np.random.Generator] = None):
        self.rng = rng if rng is not None else np.random.default_rng(42)
        self.tiles: List[int] = []
        self.tile_weights: Dict[int, float] = {}
        self.h_rules: Dict[int, Set[int]] = defaultdict(set)
        self.v_rules: Dict[int, Set[int]] = defaultdict(set)
        self._train(training_levels)

    def _train(self, levels: List[np.ndarray]) -> None:
        tile_counts: Dict[int, int] = defaultdict(int)
        for level in levels:
            H, W = level.shape
            for r in range(H):
                for c in range(W):
                    t = int(level[r, c])
                    tile_counts[t] += 1
                    if c + 1 < W:
                        self.h_rules[t].add(int(level[r, c + 1]))
                    if r + 1 < H:
                        self.v_rules[t].add(int(level[r + 1, c]))

        self.tiles = sorted(tile_counts.keys())
        total = sum(tile_counts.values())
        self.tile_weights = {t: tile_counts[t] / total for t in self.tiles}

        for t in self.tiles:
            if t not in self.h_rules:
                self.h_rules[t] = set(self.tiles)
            if t not in self.v_rules:
                self.v_rules[t] = set(self.tiles)

    def generate(self, height: int = 22, width: int = 32,
                 max_retries: int = 10) -> np.ndarray:
        for attempt in range(max_retries):
            result = self._wfc_run(height, width)
            if result is not None:
                return result
        return self._fallback_level(height, width)

    def _wfc_run(self, H: int, W: int) -> Optional[np.ndarray]:
        wave = [[set(self.tiles) for _ in range(W)] for _ in range(H)]

        def propagate(start_cells: List[Tuple[int, int]]) -> bool:
            stack = list(start_cells)
            while stack:
                r, c = stack.pop()
                current = wave[r][c]
                if not current:
                    return False

                if c + 1 < W:
                    allowed = set()
                    for t in current:
                        allowed |= self.h_rules[t]
                    new = wave[r][c + 1] & allowed
                    if new != wave[r][c + 1]:
                        if not new:
                            return False
                        wave[r][c + 1] = new
                        stack.append((r, c + 1))

                if c - 1 >= 0:
                    allowed = set()
                    for t in current:
                        for src, dsts in self.h_rules.items():
                            if t in dsts:
                                allowed.add(src)
                    new = wave[r][c - 1] & allowed
                    if new != wave[r][c - 1]:
                        if not new:
                            return False
                        wave[r][c - 1] = new
                        stack.append((r, c - 1))

                if r + 1 < H:
                    allowed = set()
                    for t in current:
                        allowed |= self.v_rules[t]
                    new = wave[r + 1][c] & allowed
                    if new != wave[r + 1][c]:
                        if not new:
                            return False
                        wave[r + 1][c] = new
                        stack.append((r + 1, c))

                if r - 1 >= 0:
                    allowed = set()
                    for t in current:
                        for src, dsts in self.v_rules.items():
                            if t in dsts:
                                allowed.add(src)
                    new = wave[r - 1][c] & allowed
                    if new != wave[r - 1][c]:
                        if not new:
                            return False
                        wave[r - 1][c] = new
                        stack.append((r - 1, c))

            return True

        while True:
            min_entropy = float('inf')
            min_cells = []
            all_collapsed = True

            for r in range(H):
                for c in range(W):
                    n = len(wave[r][c])
                    if n == 0:
                        return None
                    if n > 1:
                        all_collapsed = False
                        if n < min_entropy:
                            min_entropy = n
                            min_cells = [(r, c)]
                        elif n == min_entropy:
                            min_cells.append((r, c))

            if all_collapsed:
                break

            r, c = min_cells[self.rng.integers(len(min_cells))]
            options = list(wave[r][c])
            weights = np.array([self.tile_weights.get(t, 1e-6)
                                 for t in options])
            weights /= weights.sum()
            chosen = options[self.rng.choice(len(options), p=weights)]
            wave[r][c] = {chosen}

            if not propagate([(r, c)]):
                return None

        level = np.zeros((H, W), dtype=np.int32)
        for r in range(H):
            for c in range(W):
                level[r, c] = next(iter(wave[r][c]))
        return level

    def _fallback_level(self, H: int, W: int) -> np.ndarray:
        """Simple valid Lode Runner level — solid border, open interior."""
        level = np.zeros((H, W), dtype=np.int32)
        level[0, :]  = 1   # top wall
        level[-1, :] = 1   # bottom wall
        level[:, 0]  = 1   # left wall
        level[:, -1] = 1   # right wall
        return level

    def generate_batch(self, n: int, height: int = 22,
                       width: int = 32) -> List[np.ndarray]:
        return [self.generate(height=height, width=width) for _ in range(n)]
