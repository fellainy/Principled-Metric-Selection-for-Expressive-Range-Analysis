"""
generators/wfc_generator.py
---------------------------
Real WaveFunctionCollapse generator trained on VGLC Mario levels.

This is a tile-based WFC implementation that:
1. Learns adjacency constraints from real VGLC Mario levels
2. Generates new levels by constraint propagation

Usage:
    from generators.wfc_generator import WFCMarioGenerator
    gen = WFCMarioGenerator(training_levels)   # training_levels from loader.py
    level = gen.generate(height=14, width=50)

Reference:
    Gumin, M. (2016). WaveFunctionCollapse.
    https://github.com/mxgmn/WaveFunctionCollapse

    Karth, I., & Smith, A. M. (2017). WaveFunctionCollapse is constraint
    solving in the wild. FDG 2017.
"""

import numpy as np
from collections import defaultdict
from typing import List, Tuple, Dict, Set, Optional


class WFCMarioGenerator:
    """
    Tile-based WFC generator trained on VGLC Mario levels.

    Learns horizontal and vertical adjacency rules from training levels,
    then generates new levels by iterative constraint propagation.
    """

    def __init__(self, training_levels: List[np.ndarray],
                 rng: Optional[np.random.Generator] = None):
        """
        Parameters
        ----------
        training_levels : list of 2D numpy arrays from load_mario_levels()
        rng             : random generator for reproducibility
        """
        self.rng = rng if rng is not None else np.random.default_rng(42)
        self.tiles: List[int] = []
        self.tile_weights: Dict[int, float] = {}
        self.h_rules: Dict[int, Set[int]] = defaultdict(set)  # right neighbours
        self.v_rules: Dict[int, Set[int]] = defaultdict(set)  # below neighbours
        self._train(training_levels)

    def _train(self, levels: List[np.ndarray]) -> None:
        """Extract tile set, weights, and adjacency rules from training levels."""
        tile_counts: Dict[int, int] = defaultdict(int)

        for level in levels:
            H, W = level.shape
            for r in range(H):
                for c in range(W):
                    t = int(level[r, c])
                    tile_counts[t] += 1
                    # Horizontal adjacency: t can have right-neighbour
                    if c + 1 < W:
                        self.h_rules[t].add(int(level[r, c + 1]))
                    # Vertical adjacency: t can have below-neighbour
                    if r + 1 < H:
                        self.v_rules[t].add(int(level[r + 1, c]))

        self.tiles = sorted(tile_counts.keys())
        total = sum(tile_counts.values())
        self.tile_weights = {t: tile_counts[t] / total for t in self.tiles}

        # Ensure every tile has at least itself as a neighbour
        # (prevents propagation deadlocks on rare tiles)
        for t in self.tiles:
            if t not in self.h_rules:
                self.h_rules[t] = set(self.tiles)
            if t not in self.v_rules:
                self.v_rules[t] = set(self.tiles)

    def generate(self, height: int = 14, width: int = 50,
                 max_retries: int = 10) -> np.ndarray:
        """
        Generate one level using WFC constraint propagation.

        Parameters
        ----------
        height      : level height in tiles (VGLC Mario = 14)
        width       : level width in tiles  (VGLC Mario = typically 100-200;
                      50 used for consistency with corpus)
        max_retries : number of restarts if contradiction is reached

        Returns
        -------
        2D numpy array of shape (height, width), dtype int32
        """
        for attempt in range(max_retries):
            result = self._wfc_run(height, width)
            if result is not None:
                return result
        # If all retries fail, return a simple valid fallback level
        return self._fallback_level(height, width)

    def _wfc_run(self, H: int, W: int) -> Optional[np.ndarray]:
        """Single WFC run. Returns None if contradiction reached."""
        # wave[r][c] = set of still-possible tiles at cell (r, c)
        wave = [[set(self.tiles) for _ in range(W)] for _ in range(H)]

        # Propagation queue
        def propagate(start_cells: List[Tuple[int, int]]) -> bool:
            stack = list(start_cells)
            while stack:
                r, c = stack.pop()
                current = wave[r][c]
                if not current:
                    return False  # contradiction

                # Right neighbour
                if c + 1 < W:
                    allowed = set()
                    for t in current:
                        allowed |= self.h_rules[t]
                    new = wave[r][c + 1] & allowed
                    if new != wave[r][c + 1]:
                        if not new:
                            return False
                        wave[r][c + 1] = new
                        stack.append((r, c + 1))

                # Left neighbour (reverse h_rules)
                if c - 1 >= 0:
                    allowed = set()
                    for t in current:
                        # t can be right-neighbour of these tiles
                        for src, dsts in self.h_rules.items():
                            if t in dsts:
                                allowed.add(src)
                    new = wave[r][c - 1] & allowed
                    if new != wave[r][c - 1]:
                        if not new:
                            return False
                        wave[r][c - 1] = new
                        stack.append((r, c - 1))

                # Below neighbour
                if r + 1 < H:
                    allowed = set()
                    for t in current:
                        allowed |= self.v_rules[t]
                    new = wave[r + 1][c] & allowed
                    if new != wave[r + 1][c]:
                        if not new:
                            return False
                        wave[r + 1][c] = new
                        stack.append((r + 1, c))

                # Above neighbour (reverse v_rules)
                if r - 1 >= 0:
                    allowed = set()
                    for t in current:
                        for src, dsts in self.v_rules.items():
                            if t in dsts:
                                allowed.add(src)
                    new = wave[r - 1][c] & allowed
                    if new != wave[r - 1][c]:
                        if not new:
                            return False
                        wave[r - 1][c] = new
                        stack.append((r - 1, c))

            return True

        # Observation loop
        while True:
            # Find cell with minimum entropy (fewest options) > 1
            min_entropy = float('inf')
            min_cells = []
            all_collapsed = True

            for r in range(H):
                for c in range(W):
                    n = len(wave[r][c])
                    if n == 0:
                        return None  # contradiction
                    if n > 1:
                        all_collapsed = False
                        if n < min_entropy:
                            min_entropy = n
                            min_cells = [(r, c)]
                        elif n == min_entropy:
                            min_cells.append((r, c))

            if all_collapsed:
                break  # done

            # Collapse the minimum-entropy cell using tile weights
            r, c = min_cells[self.rng.integers(len(min_cells))]
            options = list(wave[r][c])
            weights = np.array([self.tile_weights.get(t, 1e-6) for t in options])
            weights /= weights.sum()
            chosen = options[self.rng.choice(len(options), p=weights)]
            wave[r][c] = {chosen}

            # Propagate
            if not propagate([(r, c)]):
                return None  # contradiction, retry

        # Collapse wave to level array
        level = np.zeros((H, W), dtype=np.int32)
        for r in range(H):
            for c in range(W):
                level[r, c] = next(iter(wave[r][c]))
        return level

    def _fallback_level(self, H: int, W: int) -> np.ndarray:
        """Simple valid Mario level used when WFC fails all retries."""
        level = np.zeros((H, W), dtype=np.int32)
        level[-1, :] = 1   # solid ground
        return level

    def generate_batch(self, n: int, height: int = 14,
                       width: int = 50) -> List[np.ndarray]:
        """Generate n levels."""
        return [self.generate(height=height, width=width) for _ in range(n)]
