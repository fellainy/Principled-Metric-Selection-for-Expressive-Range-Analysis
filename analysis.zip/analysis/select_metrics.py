"""
analysis/select_metrics.py
--------------------------
Rank all 45 metric pairs by a composite selection score and
identify which pairs make the best ERA axis pairs.

Usage:
    python analysis/select_metrics.py --data data/levels.csv
    python analysis/select_metrics.py --data data/levels.csv --top 5

Outputs (written to results/)
------------------------------
results/pair_rankings.csv   — all 45 pairs scored and ranked
results/top_pairs.csv       — top-N pairs for ERA plotting
results/correlation_matrix.png
results/pair_rankings.png   — bar chart of composite scores
"""

import sys
import argparse
from itertools import combinations
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.cm as cm
from scipy import stats
from scipy.spatial.distance import jensenshannon
from sklearn.preprocessing import MinMaxScaler

sys.path.insert(0, str(Path(__file__).parent.parent))
from metrics.compute import METRIC_FUNCTIONS

METRIC_NAMES = list(METRIC_FUNCTIONS.keys())
RESULTS_DIR  = Path("results")


# ── Scoring criteria ──────────────────────────────────────────────────────────

def score_marginal_variance(df: pd.DataFrame, m1: str, m2: str) -> float:
    """
    Average normalised variance of the two metrics.
    Low-variance metrics carry no discriminating information.
    """
    v1 = df[m1].var()
    v2 = df[m2].var()
    # Normalise by range² so metrics on different scales are comparable
    r1 = (df[m1].max() - df[m1].min()) ** 2 + 1e-9
    r2 = (df[m2].max() - df[m2].min()) ** 2 + 1e-9
    return float((v1 / r1 + v2 / r2) / 2)


def score_independence(df: pd.DataFrame, m1: str, m2: str) -> float:
    """
    Independence of the two metrics (1 - |Spearman correlation|).
    Highly correlated pairs are redundant — we want axes that tell different stories.
    Range: [0, 1]; 1.0 = perfectly independent.
    """
    pair = df[[m1, m2]].dropna()
    rho, _ = stats.spearmanr(pair[m1], pair[m2])
    if np.isnan(rho):
        return 0.0
    return 1.0 - abs(rho)


def score_coverage(df: pd.DataFrame, m1: str, m2: str, bins: int = 20) -> float:
    """
    2D coverage: fraction of the (bins × bins) grid occupied by at least one level.
    Higher = generator's range spans more of the space defined by this pair.
    Range: [0, 1].
    """
    pair = df[[m1, m2]].dropna()
    x = pair[m1]
    y = pair[m2]
    if len(x) < 10:
        return 0.0
    hist, _, _ = np.histogram2d(x, y, bins=bins,
                                 range=[[x.min(), x.max()], [y.min(), y.max()]])
    occupied = np.sum(hist > 0)
    return occupied / (bins * bins)


def score_discriminability(df: pd.DataFrame, m1: str, m2: str,
                            bins: int = 20) -> float:
    """
    Jensen-Shannon divergence between the 2D distributions of two generators.
    Higher = this pair better separates WFC from GAN output.
    Range: [0, 1].
    Requires both 'wfc' and 'gan' in the generator column.
    """
    gens = df["generator"].unique()
    if len(gens) < 2:
        return 0.0

    g1, g2 = gens[0], gens[1]
    d1 = df[df["generator"] == g1][[m1, m2]].dropna()
    d2 = df[df["generator"] == g2][[m1, m2]].dropna()
    if len(d1) < 5 or len(d2) < 5:
        return 0.0

    # Build histograms over shared range
    x_min = min(d1[m1].min(), d2[m1].min())
    x_max = max(d1[m1].max(), d2[m1].max())
    y_min = min(d1[m2].min(), d2[m2].min())
    y_max = max(d1[m2].max(), d2[m2].max())

    h1, _, _ = np.histogram2d(d1[m1], d1[m2], bins=bins,
                               range=[[x_min, x_max], [y_min, y_max]])
    h2, _, _ = np.histogram2d(d2[m1], d2[m2], bins=bins,
                               range=[[x_min, x_max], [y_min, y_max]])

    p = h1.flatten() + 1e-9   # Laplace smoothing
    q = h2.flatten() + 1e-9
    p /= p.sum()
    q /= q.sum()

    return float(jensenshannon(p, q))   # already in [0, 1]


# ── Composite scorer ──────────────────────────────────────────────────────────

CRITERIA = {
    "variance":        (score_marginal_variance, 0.25),
    "independence":    (score_independence,      0.25),
    "coverage":        (score_coverage,          0.25),
    "discriminability":(score_discriminability,  0.25),
}


def rank_pairs(df: pd.DataFrame) -> pd.DataFrame:
    """
    Score all C(N_metrics, 2) pairs and return a sorted DataFrame.
    """
    # Drop constant / all-NaN columns
    valid = [m for m in METRIC_NAMES
             if df[m].notna().sum() > 10 and df[m].std() > 0]
    dropped = set(METRIC_NAMES) - set(valid)
    if dropped:
        print(f"[warn] Dropping metrics (constant or mostly NaN): {dropped}")

    records = []
    for m1, m2 in combinations(valid, 2):
        row = {"metric_1": m1, "metric_2": m2}
        composite = 0.0
        for criterion, (fn, weight) in CRITERIA.items():
            score = fn(df, m1, m2)
            row[criterion] = round(score, 4)
            composite += weight * score
        row["composite"] = round(composite, 4)
        records.append(row)

    result = (pd.DataFrame(records)
                .sort_values("composite", ascending=False)
                .reset_index(drop=True))
    result.index += 1   # 1-based rank
    result.index.name = "rank"
    return result


# ── Visualisation ─────────────────────────────────────────────────────────────

def plot_correlation_matrix(df: pd.DataFrame, out: Path) -> None:
    corr = df[METRIC_NAMES].corr(method="spearman")
    fig, ax = plt.subplots(figsize=(9, 8))
    im = ax.imshow(corr.values, cmap="RdYlGn", vmin=-1, vmax=1)
    ax.set_xticks(range(len(METRIC_NAMES)))
    ax.set_yticks(range(len(METRIC_NAMES)))
    ax.set_xticklabels(METRIC_NAMES, rotation=45, ha="right", fontsize=9)
    ax.set_yticklabels(METRIC_NAMES, fontsize=9)
    plt.colorbar(im, ax=ax, label="Spearman ρ")
    ax.set_title("Metric Correlation Matrix (Spearman)", fontsize=12)
    plt.tight_layout()
    fig.savefig(out, dpi=150)
    plt.close(fig)
    print(f"  Saved: {out}")


def plot_pair_rankings(rankings: pd.DataFrame, top_n: int, out: Path) -> None:
    top = rankings.head(top_n)
    labels = [f"{r.metric_1}\n× {r.metric_2}" for _, r in top.iterrows()]
    fig, ax = plt.subplots(figsize=(max(8, top_n * 1.2), 5))
    bars = ax.bar(labels, top["composite"], color=cm.Blues_r(
        np.linspace(0.3, 0.8, len(top))))
    ax.set_ylabel("Composite score")
    ax.set_title(f"Top {top_n} ERA metric pairs by composite score")
    ax.set_ylim(0, 1)
    for bar, val in zip(bars, top["composite"]):
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.01,
                f"{val:.2f}", ha="center", va="bottom", fontsize=8)
    plt.tight_layout()
    fig.savefig(out, dpi=150)
    plt.close(fig)
    print(f"  Saved: {out}")


def plot_era(df: pd.DataFrame, m1: str, m2: str, out: Path) -> None:
    """ERA density plot for a single metric pair, coloured by generator."""
    fig, ax = plt.subplots(figsize=(7, 6))
    colors = {"wfc": "#2196F3", "gan": "#FF5722"}
    for gen, group in df.groupby("generator"):
        g = group[[m1, m2]].dropna()
        ax.scatter(g[m1], g[m2], alpha=0.25, s=10,
                   color=colors.get(gen, "grey"), label=gen)
    ax.set_xlabel(m1.replace("_", " ").title())
    ax.set_ylabel(m2.replace("_", " ").title())
    ax.set_title(f"ERA: {m1} × {m2}")
    ax.legend()
    plt.tight_layout()
    fig.savefig(out, dpi=150)
    plt.close(fig)


# ── Main ─────────────────────────────────────────────────────────────────────

def main(data_path: Path, top_n: int) -> None:
    print(f"Loading: {data_path}")
    df = pd.read_csv(data_path)
    print(f"  {len(df)} levels, generators: {df['generator'].unique()}")

    RESULTS_DIR.mkdir(parents=True, exist_ok=True)

    print("\nComputing correlation matrix…")
    plot_correlation_matrix(df, RESULTS_DIR / "correlation_matrix.png")

    print("\nRanking metric pairs…")
    rankings = rank_pairs(df)
    rankings.to_csv(RESULTS_DIR / "pair_rankings.csv")
    print(f"  Saved: {RESULTS_DIR / 'pair_rankings.csv'}")

    top = rankings.head(top_n)
    top.to_csv(RESULTS_DIR / "top_pairs.csv")
    print(f"\nTop {top_n} pairs:")
    print(top[["metric_1", "metric_2", "composite",
                "variance", "independence", "coverage",
                "discriminability"]].to_string())

    print("\nGenerating pair ranking chart…")
    plot_pair_rankings(rankings, top_n,
                       RESULTS_DIR / "pair_rankings.png")

    print(f"\nGenerating ERA plots for top {top_n} pairs…")
    for _, row in top.iterrows():
        fname = f"era_{row.metric_1}_x_{row.metric_2}.png"
        plot_era(df, row.metric_1, row.metric_2, RESULTS_DIR / fname)

    # Also plot the conventional pair for comparison
    if "leniency" in df.columns and "linearity" in df.columns:
        print("\nGenerating conventional ERA plot (leniency × linearity)…")
        plot_era(df, "leniency", "linearity",
                 RESULTS_DIR / "era_conventional_leniency_x_linearity.png")

    print(f"\n✓ All results written to {RESULTS_DIR}/")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=str, default="data/levels.csv")
    parser.add_argument("--top",  type=int, default=5,
                        help="Number of top pairs to report and plot")
    args = parser.parse_args()
    main(Path(args.data), args.top)
