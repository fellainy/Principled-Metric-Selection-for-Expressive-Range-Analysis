"""
analysis/validate.py
--------------------
Four computational validations replacing the human study (Month 4).

Validations
-----------
A  Structure preservation   — Trustworthiness + Shepard diagram correlation
B  Generator discrimination — Leave-one-generator-out AUC
C  Injected variation       — Kendall τ, silhouette width, η² over swept parameter
D  Reliability              — Split-half Spearman ≥ 0.70 over 500 splits

Usage
-----
    python analysis/validate.py --data data/levels.csv --top_pairs results/top_pairs.csv
    python analysis/validate.py --data data/levels.csv --top_pairs results/top_pairs.csv --n_splits 500

Outputs (written to results/validation/)
-----------------------------------------
validation_summary.csv      — one row per pair per validation, all scores
validation_report.txt       — human-readable summary for paper Results section
shepard_<pair>.png          — Shepard diagram for each top pair (Validation A)
injected_variation_<pair>.png — sweep plots (Validation C)
"""

import sys
import argparse
import warnings
from itertools import combinations
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats
from scipy.spatial.distance import pdist, squareform
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import silhouette_score

warnings.filterwarnings("ignore", category=stats.ConstantInputWarning)

sys.path.insert(0, str(Path(__file__).parent.parent))
from metrics.compute import compute_all, METRIC_FUNCTIONS

METRIC_NAMES  = list(METRIC_FUNCTIONS.keys())
VAL_DIR       = Path("results/validation")


# ══════════════════════════════════════════════════════════════════════════════
# VALIDATION A — Structure Preservation
# ══════════════════════════════════════════════════════════════════════════════

def _trustworthiness(D_high: np.ndarray, D_low: np.ndarray, k: int = 10) -> float:
    """
    Venna & Kaski (2001) trustworthiness.
    Measures whether points that are close in the 2D plot were also close
    in the full high-dimensional metric space.
    Range [0, 1]; 1.0 = perfect neighbourhood preservation.
    """
    n = D_high.shape[0]
    rank_high = np.argsort(np.argsort(D_high, axis=1), axis=1)  # rank in HD space
    rank_low  = np.argsort(D_low,  axis=1)                       # sorted order in LD

    T = 0.0
    for i in range(n):
        # k nearest neighbours in the 2D plot
        nn_low = rank_low[i, 1:k + 1]
        for j in nn_low:
            r = rank_high[i, j]   # rank of j in HD space for point i
            if r > k:
                T += (r - k)

    norm = (2.0 / (n * k * (2 * n - 3 * k - 1)))
    return float(1.0 - norm * T)


def _shepard_correlation(D_high: np.ndarray, D_low: np.ndarray) -> float:
    """
    Pearson r between all pairwise distances in HD and 2D spaces.
    Range [-1, 1]; values ≥ 0.80 indicate good structure preservation.
    """
    idx   = np.triu_indices(D_high.shape[0], k=1)
    d_h   = D_high[idx]
    d_l   = D_low[idx]
    r, _  = stats.pearsonr(d_h, d_l)
    return float(r)


def validate_structure(df: pd.DataFrame, m1: str, m2: str,
                       pair_label: str, k: int = 10) -> dict:
    """Validation A for one metric pair."""
    valid_metrics = [m for m in METRIC_NAMES if df[m].notna().all()]
    sub = df[valid_metrics].dropna()

    scaler   = MinMaxScaler()
    X_high   = scaler.fit_transform(sub[valid_metrics])
    X_low    = scaler.fit_transform(sub[[m1, m2]])

    D_high   = squareform(pdist(X_high, metric="euclidean"))
    D_low    = squareform(pdist(X_low,  metric="euclidean"))

    T        = _trustworthiness(D_high, D_low, k=k)
    shepard_r = _shepard_correlation(D_high, D_low)

    # Shepard diagram (sample 500 pairs for speed)
    idx = np.triu_indices(D_high.shape[0], k=1)
    sample = np.random.default_rng(42).choice(len(idx[0]),
                                               size=min(500, len(idx[0])),
                                               replace=False)
    d_h_s = D_high[idx][sample]
    d_l_s = D_low[idx][sample]

    fig, ax = plt.subplots(figsize=(5, 5))
    ax.scatter(d_h_s, d_l_s, alpha=0.3, s=8, color="#2196F3")
    ax.set_xlabel("HD pairwise distance (10 metrics)")
    ax.set_ylabel("2D pairwise distance")
    ax.set_title(f"Shepard diagram: {m1} × {m2}\nr = {shepard_r:.3f}")
    m_fit, b_fit = np.polyfit(d_h_s, d_l_s, 1)
    xs = np.linspace(d_h_s.min(), d_h_s.max(), 100)
    ax.plot(xs, m_fit * xs + b_fit, color="red", linewidth=1.5)
    plt.tight_layout()
    out = VAL_DIR / f"shepard_{pair_label}.png"
    fig.savefig(out, dpi=150)
    plt.close(fig)

    return {"trustworthiness": round(T, 4),
            "shepard_r":       round(shepard_r, 4),
            "shepard_plot":    str(out)}


# ══════════════════════════════════════════════════════════════════════════════
# VALIDATION B — Held-out Generator Discrimination
# ══════════════════════════════════════════════════════════════════════════════

def validate_discrimination(df: pd.DataFrame, m1: str, m2: str) -> dict:
    """
    Leave-one-generator-out AUC.
    For each generator g:
      1. Select the top pair using only levels NOT from g.
      2. Apply that pair to g's levels and a random same-size sample of others.
      3. Score AUC: can the 2D coordinates separate g from the rest?
    Returns mean AUC across all generators.
    """
    generators = df["generator"].unique()
    aucs = []

    for g in generators:
        mask_out  = df["generator"] != g
        mask_in   = df["generator"] == g

        # Features: just the two metric values
        X_all     = df[[m1, m2]].fillna(0).values
        y         = (df["generator"] == g).astype(int).values

        # Simple distance-based score: distance from centroid of the held-in
        # generator's cloud (computed on hold-out data only)
        centroid  = X_all[mask_out & (df["generator"] != g)].mean(axis=0) \
                    if mask_out.sum() > 0 else X_all[mask_in].mean(axis=0)
        centroid_g = X_all[mask_in].mean(axis=0)

        # Score = distance to g-centroid minus distance to others-centroid
        scores = (np.linalg.norm(X_all - centroid,   axis=1) -
                  np.linalg.norm(X_all - centroid_g, axis=1))

        try:
            auc = roc_auc_score(y, -scores)   # negative: closer to g = higher score
            aucs.append(auc)
        except Exception:
            pass

    mean_auc = float(np.mean(aucs)) if aucs else float("nan")
    return {"loo_auc": round(mean_auc, 4),
            "n_generators": len(generators)}


# ══════════════════════════════════════════════════════════════════════════════
# VALIDATION C — Recovery of Injected Variation
# ══════════════════════════════════════════════════════════════════════════════

def _inject_variation(n_per_step: int = 100,
                      rng: np.random.Generator = None) -> pd.DataFrame:
    """
    Sweep a known generator parameter (gap_rate for Mario) across 8 steps.
    For each step, generate n_per_step synthetic levels and compute all metrics.
    Returns a DataFrame with columns: step, gap_rate, <metrics>.

    This is the 'preregistered known variation' — we impose it, so ground truth
    is the step order (0..7).
    """
    if rng is None:
        rng = np.random.default_rng(0)

    gap_rates = np.linspace(0.02, 0.25, 8)   # 8 steps: easy → hard
    rows = []

    for step, gap_rate in enumerate(gap_rates):
        for _ in range(n_per_step):
            H, W = 14, 50
            level = np.zeros((H, W), dtype=np.int32)
            level[-1, :] = 1                          # ground row
            # Inject gaps at the preregistered rate
            n_gaps = int(W * gap_rate)
            gap_cols = rng.choice(W, size=n_gaps, replace=False)
            level[-1, gap_cols] = 0
            # Random platforms
            for _ in range(rng.integers(1, 5)):
                r   = rng.integers(H // 2, H - 2)
                c   = rng.integers(0, W - 4)
                w   = rng.integers(2, 5)
                level[r, c:c+w] = 1
            # Enemies
            for col in rng.integers(0, W, size=rng.integers(0, 4)):
                level[-2, col] = 3

            metrics = compute_all(level, "mario")
            rows.append({"step": step, "gap_rate": float(gap_rate), **metrics})

    return pd.DataFrame(rows)


def validate_injected_variation(m1: str, m2: str, pair_label: str,
                                 n_per_step: int = 100) -> dict:
    """
    Validation C: does the pair reveal a known, imposed ordering?

    Metrics
    -------
    Kendall's τ : rank correlation between step order and per-step centroid along m1
    Silhouette  : cluster separation between steps in 2D space
    η²          : effect size of step on m1 (one-way ANOVA)
    """
    print(f"    Generating injected-variation corpus ({8 * n_per_step} levels)…")
    df_inj = _inject_variation(n_per_step=n_per_step)

    # ── Kendall τ: does median m1 increase monotonically with step? ──────────
    step_medians = df_inj.groupby("step")[m1].median().values
    tau, p_tau   = stats.kendalltau(np.arange(len(step_medians)), step_medians)

    # ── Silhouette width in the 2D (m1, m2) space ────────────────────────────
    X_2d   = df_inj[[m1, m2]].fillna(0).values
    labels = df_inj["step"].values
    try:
        sil = silhouette_score(X_2d, labels, metric="euclidean",
                               sample_size=min(2000, len(X_2d)))
    except Exception:
        sil = float("nan")

    # ── η²: one-way ANOVA of m1 across steps ─────────────────────────────────
    groups     = [df_inj[df_inj["step"] == s][m1].dropna().values
                  for s in df_inj["step"].unique()]
    grand_mean = df_inj[m1].mean()
    ss_between = sum(len(g) * (g.mean() - grand_mean) ** 2
                     for g in groups if len(g) > 0)
    ss_total   = sum((v - grand_mean) ** 2 for g in groups for v in g)
    eta2       = float(ss_between / ss_total) if ss_total > 0 else float("nan")

    # ── Plot: step vs m1 median with error bars ───────────────────────────────
    summary = df_inj.groupby("step")[m1].agg(["median", "std"]).reset_index()
    fig, axes = plt.subplots(1, 2, figsize=(11, 4))

    axes[0].errorbar(summary["step"], summary["median"], yerr=summary["std"],
                     fmt="o-", color="#2196F3", capsize=4)
    axes[0].set_xlabel("Gap-rate step (0=easy → 7=hard)")
    axes[0].set_ylabel(m1.replace("_", " ").title())
    axes[0].set_title(f"Injected variation → {m1}\nKendall τ={tau:.3f}, p={p_tau:.3f}")

    for s in df_inj["step"].unique():
        sub = df_inj[df_inj["step"] == s]
        axes[1].scatter(sub[m1], sub[m2], alpha=0.15, s=8,
                        c=[plt.cm.viridis(s / 7)] * len(sub))
    axes[1].set_xlabel(m1.replace("_", " ").title())
    axes[1].set_ylabel(m2.replace("_", " ").title())
    axes[1].set_title(f"ERA: {m1} × {m2}\nsilhouette={sil:.3f}, η²={eta2:.3f}")

    sm = plt.cm.ScalarMappable(cmap="viridis",
                                norm=plt.Normalize(vmin=0, vmax=7))
    sm.set_array([])
    plt.colorbar(sm, ax=axes[1], label="Step (0=easy, 7=hard)")
    plt.tight_layout()
    out = VAL_DIR / f"injected_variation_{pair_label}.png"
    fig.savefig(out, dpi=150)
    plt.close(fig)

    return {"kendall_tau":   round(float(tau),  4),
            "kendall_p":     round(float(p_tau), 4),
            "silhouette":    round(float(sil),   4),
            "eta_squared":   round(float(eta2),  4),
            "inj_plot":      str(out)}


# ══════════════════════════════════════════════════════════════════════════════
# VALIDATION D — Split-half Reliability
# ══════════════════════════════════════════════════════════════════════════════

def _score_pairs_on_subset(df_sub: pd.DataFrame) -> pd.Series:
    """
    Compute composite scores for all pairs on a data subset.
    Returns a Series indexed by 'metric_1__metric_2'.
    """
    from analysis.select_metrics import (score_marginal_variance,
                                          score_independence,
                                          score_coverage,
                                          score_discriminability)
    valid = [m for m in METRIC_NAMES
             if df_sub[m].notna().sum() > 5 and df_sub[m].std() > 0]
    scores = {}
    for m1, m2 in combinations(valid, 2):
        key = f"{m1}__{m2}"
        try:
            composite = (score_marginal_variance(df_sub, m1, m2) * 0.25 +
                         score_independence(df_sub, m1, m2)      * 0.25 +
                         score_coverage(df_sub, m1, m2)          * 0.25 +
                         score_discriminability(df_sub, m1, m2)  * 0.25)
            scores[key] = composite
        except Exception:
            scores[key] = float("nan")
    return pd.Series(scores)


def validate_reliability(df: pd.DataFrame, n_splits: int = 500,
                          threshold: float = 0.70) -> dict:
    """
    Validation D: split-half Spearman reliability of the 45-pair ranking.

    For each of n_splits random 50/50 splits of the level corpus:
      1. Score all pairs on the first half
      2. Score all pairs on the second half
      3. Compute Spearman ρ between the two ranking vectors

    Report mean ρ, std, and whether mean ρ ≥ threshold (0.70).
    """
    rng   = np.random.default_rng(42)
    rhos  = []
    n     = len(df)

    print(f"    Running {n_splits} split-half iterations…")
    for i in range(n_splits):
        idx     = rng.permutation(n)
        half    = n // 2
        df_a    = df.iloc[idx[:half]].reset_index(drop=True)
        df_b    = df.iloc[idx[half:]].reset_index(drop=True)

        scores_a = _score_pairs_on_subset(df_a)
        scores_b = _score_pairs_on_subset(df_b)

        common   = scores_a.index.intersection(scores_b.index)
        if len(common) < 5:
            continue

        rho, _   = stats.spearmanr(scores_a[common].fillna(0),
                                    scores_b[common].fillna(0))
        if not np.isnan(rho):
            rhos.append(rho)

        if (i + 1) % 100 == 0:
            print(f"      {i + 1}/{n_splits} splits done, "
                  f"running mean ρ = {np.mean(rhos):.3f}")

    mean_rho  = float(np.mean(rhos))
    std_rho   = float(np.std(rhos))
    passes    = mean_rho >= threshold

    return {"mean_spearman_rho": round(mean_rho, 4),
            "std_spearman_rho":  round(std_rho,  4),
            "threshold":         threshold,
            "passes_threshold":  passes,
            "n_splits":          len(rhos)}


# ══════════════════════════════════════════════════════════════════════════════
# Report writer
# ══════════════════════════════════════════════════════════════════════════════

def write_report(summary: pd.DataFrame, reliability: dict, out: Path) -> None:
    lines = [
        "=" * 65,
        "ERA METRIC SELECTION — VALIDATION REPORT",
        "=" * 65,
        "",
        "VALIDATION A — Structure Preservation (per pair)",
        "-" * 65,
    ]
    for _, row in summary.iterrows():
        label = f"{row.metric_1} × {row.metric_2}"
        lines.append(f"  {label:<40}  "
                     f"T={row.trustworthiness:.3f}  "
                     f"Shepard r={row.shepard_r:.3f}")
    lines += [
        "",
        "  Interpretation: T ≥ 0.90 and Shepard r ≥ 0.80 indicate",
        "  that the 2D plot faithfully preserves neighbourhood",
        "  structure from the full 10-metric space.",
        "",
        "VALIDATION B — Generator Discrimination (per pair)",
        "-" * 65,
    ]
    for _, row in summary.iterrows():
        label = f"{row.metric_1} × {row.metric_2}"
        lines.append(f"  {label:<40}  LOO-AUC={row.loo_auc:.3f}")
    lines += [
        "",
        "  Interpretation: AUC > 0.70 indicates the pair separates",
        "  generators better than chance.",
        "",
        "VALIDATION C — Injected Variation Recovery (per pair)",
        "-" * 65,
    ]
    for _, row in summary.iterrows():
        label = f"{row.metric_1} × {row.metric_2}"
        lines.append(f"  {label:<40}  "
                     f"τ={row.kendall_tau:.3f}  "
                     f"sil={row.silhouette:.3f}  "
                     f"η²={row.eta_squared:.3f}")
    lines += [
        "",
        "  Interpretation: τ ≥ 0.70 means the pair reveals the",
        "  imposed ordering. η² ≥ 0.14 is a large effect (Cohen).",
        "",
        "VALIDATION D — Split-half Reliability (corpus-level)",
        "-" * 65,
        f"  Mean Spearman ρ = {reliability['mean_spearman_rho']:.4f} "
        f"± {reliability['std_spearman_rho']:.4f}",
        f"  Threshold       = {reliability['threshold']}",
        f"  N splits        = {reliability['n_splits']}",
        f"  PASSES          = {reliability['passes_threshold']}",
        "",
        "  Interpretation: ρ ≥ 0.70 means the pair rankings are",
        "  stable and not driven by sampling noise.",
        "",
        "=" * 65,
    ]
    out.write_text("\n".join(lines), encoding="utf-8")
    print(f"\n  Saved report: {out}")


# ══════════════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════════════

def main(data_path: Path, top_pairs_path: Path, n_splits: int) -> None:
    VAL_DIR.mkdir(parents=True, exist_ok=True)

    print(f"Loading corpus: {data_path}")
    df = pd.read_csv(data_path)

    print(f"Loading top pairs: {top_pairs_path}")
    top_pairs = pd.read_csv(top_pairs_path)

    records = []

    for _, pair_row in top_pairs.iterrows():
        m1    = pair_row["metric_1"]
        m2    = pair_row["metric_2"]
        label = f"{m1}_x_{m2}"
        print(f"\n── Validating pair: {m1} × {m2}")

        print("  A: Structure preservation…")
        res_a = validate_structure(df, m1, m2, label)

        print("  B: Generator discrimination…")
        res_b = validate_discrimination(df, m1, m2)

        print("  C: Injected variation recovery…")
        res_c = validate_injected_variation(m1, m2, label, n_per_step=100)

        records.append({
            "metric_1":       m1,
            "metric_2":       m2,
            **{k: v for k, v in res_a.items() if k != "shepard_plot"},
            **{k: v for k, v in res_b.items()},
            **{k: v for k, v in res_c.items() if k != "inj_plot"},
        })

    summary = pd.DataFrame(records)
    summary.to_csv(VAL_DIR / "validation_summary.csv", index=False)
    print(f"\n  Saved: {VAL_DIR / 'validation_summary.csv'}")

    print(f"\n── Validation D: Split-half reliability ({n_splits} splits)…")
    reliability = validate_reliability(df, n_splits=n_splits)

    print(f"\n  Mean ρ = {reliability['mean_spearman_rho']:.4f}  "
          f"(threshold={reliability['threshold']}, "
          f"passes={reliability['passes_threshold']})")

    rel_df = pd.DataFrame([reliability])
    rel_df.to_csv(VAL_DIR / "reliability.csv", index=False)

    write_report(summary, reliability, VAL_DIR / "validation_report.txt")

    print("\n✓ All validations complete.")
    print(f"  Results in: {VAL_DIR}/")
    print("\nFull summary:")
    print(summary[["metric_1", "metric_2",
                    "trustworthiness", "shepard_r",
                    "loo_auc",
                    "kendall_tau", "silhouette", "eta_squared"]].to_string(index=False))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data",       type=str,
                        default="data/levels.csv")
    parser.add_argument("--top_pairs",  type=str,
                        default="results/top_pairs.csv")
    parser.add_argument("--n_splits",   type=int, default=500,
                        help="Number of split-half iterations for Validation D")
    args = parser.parse_args()
    main(Path(args.data), Path(args.top_pairs), args.n_splits)
