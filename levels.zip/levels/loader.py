"""
levels/loader.py
----------------
Load levels from the Video Game Level Corpus (VGLC) as 2D numpy arrays.

Supported domains
-----------------
Mario    : Super Mario Bros (platformer)   — 15 levels, 14×202 tiles
Dungeon  : Lode Runner                     — 150 levels, 22×32 tiles

Usage:
    from levels.loader import load_mario_levels, load_dungeon_levels

VGLC repo: https://github.com/TheVGLC/TheVGLC
Clone it, then set VGLC_ROOT to your local path.
"""

import os
import numpy as np
from pathlib import Path
from typing import List

# ── Configuration ─────────────────────────────────────────────────────────────
VGLC_ROOT = Path(os.environ.get("VGLC_ROOT", "./TheVGLC"))

# ── Mario tile mapping ────────────────────────────────────────────────────────
# Source: Super Mario Bros/Processed/*.txt
# Tile chars: ['-', '<', '>', '?', 'E', 'Q', 'S', 'X', '[', ']']
MARIO_TILE_MAP = {
    "-": 0,   # empty/air
    "X": 1,   # solid ground
    "S": 1,   # breakable brick (treat as solid)
    "?": 2,   # question block
    "Q": 2,   # used question block
    "E": 3,   # enemy
    "<": 4,   # pipe top-left
    ">": 4,   # pipe top-right
    "[": 4,   # pipe left
    "]": 4,   # pipe right
    "o": 5,   # coin
    "B": 6,   # bullet bill cannon
    "b": 6,   # bullet bill
}
MARIO_SOLID = {1, 2, 4, 6}   # tile IDs that block movement

# ── Lode Runner tile mapping ──────────────────────────────────────────────────
# Source: Lode Runner/Processed/*.txt
# Tile chars: ['#', '-', '.', 'B', 'E', 'G', 'M', 'b']
# '#' = solid brick (destructible)
# 'B' = solid brick (permanent)
# '-' = air/empty
# '.' = floor (walkable)
# 'b' = ladder
# 'E' = ladder exit
# 'G' = gold (collectible)
# 'M' = monk (enemy)
DUNGEON_TILE_MAP = {
    "#": 1,   # solid brick (destructible)
    "B": 1,   # solid brick (permanent)
    "-": 0,   # air/empty
    ".": 0,   # floor walkable
    "b": 2,   # ladder
    "E": 2,   # ladder exit
    "G": 3,   # gold collectible
    "M": 4,   # enemy monk
}
DUNGEON_SOLID = {1}   # only solid bricks block movement


# ── Internal parser ───────────────────────────────────────────────────────────

def _parse_ascii_level(path: Path, tile_map: dict,
                        default: int = 0) -> np.ndarray:
    """Read a .txt VGLC level file into a 2D int array."""
    rows = []
    with open(path, encoding="utf-8", errors="replace") as f:
        for line in f:
            line = line.rstrip("\n")
            if not line:
                continue
            rows.append([tile_map.get(ch, default) for ch in line])
    if not rows:
        raise ValueError(f"Empty level file: {path}")
    width = max(len(r) for r in rows)
    padded = [r + [default] * (width - len(r)) for r in rows]
    return np.array(padded, dtype=np.int32)


# ── Public loaders ────────────────────────────────────────────────────────────

def load_mario_levels(max_levels: int = None) -> List[np.ndarray]:
    """
    Load Super Mario Bros levels from VGLC.
    Returns list of 2D numpy arrays (14 × ~202), dtype int32.
    """
    level_dir = VGLC_ROOT / "Super Mario Bros" / "Processed"
    if not level_dir.exists():
        raise FileNotFoundError(
            f"VGLC Mario levels not found at {level_dir}.\n"
            "Clone https://github.com/TheVGLC/TheVGLC and set VGLC_ROOT."
        )
    paths = sorted(level_dir.glob("*.txt"))
    if max_levels:
        paths = paths[:max_levels]
    levels = [_parse_ascii_level(p, MARIO_TILE_MAP) for p in paths]
    print(f"  Loaded {len(levels)} Mario levels from VGLC")
    return levels


def load_dungeon_levels(max_levels: int = None) -> List[np.ndarray]:
    """
    Load Lode Runner levels from VGLC.
    Returns list of 2D numpy arrays (22 × 32), dtype int32.
    150 levels available.
    """
    level_dir = VGLC_ROOT / "Lode Runner" / "Processed"
    if not level_dir.exists():
        raise FileNotFoundError(
            f"VGLC Lode Runner levels not found at {level_dir}.\n"
            "Clone https://github.com/TheVGLC/TheVGLC and set VGLC_ROOT."
        )
    paths = sorted(level_dir.glob("*.txt"))
    if max_levels:
        paths = paths[:max_levels]
    levels = [_parse_ascii_level(p, DUNGEON_TILE_MAP) for p in paths]
    print(f"  Loaded {len(levels)} Lode Runner levels from VGLC")
    return levels


# ── Synthetic fallback (smoke-testing only) ───────────────────────────────────

def make_synthetic_mario(n: int = 10, width: int = 50, height: int = 14,
                          rng: np.random.Generator = None) -> List[np.ndarray]:
    """
    Synthetic Mario levels for pipeline smoke-testing only.
    NOT for research use.
    """
    if rng is None:
        rng = np.random.default_rng(42)
    levels = []
    for _ in range(n):
        level = np.zeros((height, width), dtype=np.int32)
        level[-1, :] = 1
        for col in rng.choice(width, size=rng.integers(2, 6), replace=False):
            level[-1, col] = 0
        for _ in range(rng.integers(2, 8)):
            row = rng.integers(height // 2, height - 2)
            col = rng.integers(0, width - 4)
            w   = rng.integers(2, 5)
            level[row, col:col + w] = 1
        for col in rng.integers(0, width, size=rng.integers(1, 5)):
            level[-2, col] = 3
        levels.append(level)
    return levels


def make_synthetic_dungeon(n: int = 10, height: int = 22, width: int = 32,
                            rng: np.random.Generator = None) -> List[np.ndarray]:
    """
    Synthetic Lode Runner-style levels for smoke-testing only.
    NOT for research use.
    """
    if rng is None:
        rng = np.random.default_rng(42)
    levels = []
    for _ in range(n):
        lvl = np.ones((height, width), dtype=np.int32)
        for _ in range(rng.integers(3, 8)):
            r  = rng.integers(1, height - 4)
            c  = rng.integers(1, width - 8)
            rh = rng.integers(2, 5)
            rw = rng.integers(4, 9)
            lvl[r:r+rh, c:c+rw] = 0
        for row in range(2, height - 2, 4):
            lvl[row, 1:-1] = 0
        levels.append(lvl)
    return levels
