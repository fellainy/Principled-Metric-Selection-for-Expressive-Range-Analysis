"""
levels/loader.py
----------------
Load levels from the Video Game Level Corpus (VGLC) as 2D numpy arrays.

Usage:
    from levels.loader import load_mario_levels, load_dungeon_levels

VGLC repo: https://github.com/TheVGLC/TheVGLC
Clone it, then set VGLC_ROOT to your local path.
"""

import os
import numpy as np
from pathlib import Path
from typing import List, Tuple

# ── Configuration ─────────────────────────────────────────────────────────────
VGLC_ROOT = Path(os.environ.get("VGLC_ROOT", "./TheVGLC"))

# Mario tile mapping: VGLC uses single characters per tile
MARIO_TILE_MAP = {
    "-": 0,   # empty/air
    "X": 1,   # solid ground
    "S": 1,   # breakable brick (treat as solid)
    "?": 2,   # question block
    "Q": 2,   # used question block
    "E": 3,   # enemy
    "<": 4,   # pipe top-left
    ">": 4,   # pipe top-right
    "[": 4,   # pipe left
    "]": 4,   # pipe right
    "o": 5,   # coin
    "B": 6,   # bullet bill cannon
    "b": 6,   # bullet bill
}
MARIO_SOLID = {1, 2, 4, 6}  # tile IDs that block movement

# Dungeon tile mapping
DUNGEON_TILE_MAP = {
    ".": 0,   # floor
    "w": 1,   # wall
    "+": 2,   # door
    "A": 3,   # player start
    "B": 3,   # boss/enemy
    "1": 3,   # enemy
}
DUNGEON_SOLID = {1}


# ── Loaders ───────────────────────────────────────────────────────────────────

def _parse_ascii_level(path: Path, tile_map: dict, default: int = 0) -> np.ndarray:
    """Read a .txt VGLC level file into a 2D int array."""
    rows = []
    with open(path) as f:
        for line in f:
            line = line.rstrip("\n")
            if not line:
                continue
            rows.append([tile_map.get(ch, default) for ch in line])
    if not rows:
        raise ValueError(f"Empty level file: {path}")
    # Pad rows to equal width
    width = max(len(r) for r in rows)
    padded = [r + [default] * (width - len(r)) for r in rows]
    return np.array(padded, dtype=np.int32)


def load_mario_levels(max_levels: int = None) -> List[np.ndarray]:
    """
    Load Super Mario Bros levels from VGLC.
    Returns a list of 2D numpy arrays (height × width), dtype int32.
    """
    level_dir = VGLC_ROOT / "Super Mario Bros" / "Processed"
    if not level_dir.exists():
        raise FileNotFoundError(
            f"VGLC Mario levels not found at {level_dir}.\n"
            "Clone https://github.com/TheVGLC/TheVGLC and set VGLC_ROOT."
        )
    paths = sorted(level_dir.glob("*.txt"))
    if max_levels:
        paths = paths[:max_levels]
    return [_parse_ascii_level(p, MARIO_TILE_MAP) for p in paths]


def load_dungeon_levels(max_levels: int = None) -> List[np.ndarray]:
    """
    Load dungeon levels from VGLC (Kid Icarus or Zelda subset).
    Returns a list of 2D numpy arrays (height × width), dtype int32.
    """
    # VGLC has several dungeon-style games; try Zelda first, then Kid Icarus
    for subdir in ["Legend of Zelda", "Kid Icarus"]:
        level_dir = VGLC_ROOT / subdir / "Processed"
        if level_dir.exists():
            break
    else:
        raise FileNotFoundError(
            f"VGLC dungeon levels not found under {VGLC_ROOT}.\n"
            "Clone https://github.com/TheVGLC/TheVGLC and set VGLC_ROOT."
        )
    paths = sorted(level_dir.glob("*.txt"))
    if max_levels:
        paths = paths[:max_levels]
    return [_parse_ascii_level(p, DUNGEON_TILE_MAP) for p in paths]


# ── Synthetic fallback (for testing without VGLC) ─────────────────────────────

def make_synthetic_mario(n: int = 10, width: int = 50, height: int = 14,
                          rng: np.random.Generator = None) -> List[np.ndarray]:
    """
    Generate simple synthetic Mario-style levels for pipeline testing.
    NOT intended for research use — only to verify the pipeline runs.
    """
    if rng is None:
        rng = np.random.default_rng(42)
    levels = []
    for _ in range(n):
        level = np.zeros((height, width), dtype=np.int32)
        level[-1, :] = 1                                 # ground row
        # Random gaps
        for col in rng.choice(width, size=rng.integers(2, 6), replace=False):
            level[-1, col] = 0
        # Random platforms
        for _ in range(rng.integers(2, 8)):
            row = rng.integers(height // 2, height - 2)
            col = rng.integers(0, width - 4)
            w   = rng.integers(2, 5)
            level[row, col:col + w] = 1
        # Random enemies
        for col in rng.integers(0, width, size=rng.integers(1, 5)):
            level[-2, col] = 3
        levels.append(level)
    return levels
